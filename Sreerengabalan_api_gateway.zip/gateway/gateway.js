const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");

const app = express();
const PORT = 3004;


app.get("/",(req,res)=>
{
  res.send("hello for gateway")
})
app.use("/user-service",
  createProxyMiddleware({
    target: "http://127.0.0.1:3000",
    pathRewrite:{
      '^/user-service':''
    }
    
  })
);


app.use("/product-service",
  createProxyMiddleware({
    target: "http://127.0.0.1:3001",
    changeOrigin: true,
    pathRewrite:{
      '^/product-service':''
    }
    
  })
);


app.use("/order-service",
  createProxyMiddleware({
    target: "http://127.0.0.1:3002",
    pathRewrite:{
      '^/order-service':''
    }
  })
);


app.use((err, req, res, next) => {
  console.error("Gateway error:", err.message);
  res.status(502).json({
    error: "Service unavailable. Please try again later.",
    details: err.message,
  });
});

app.listen(PORT, () => {
  console.log(`🚪 API Gateway running on http://localhost:${PORT}`);
});

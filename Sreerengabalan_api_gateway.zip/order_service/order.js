const express = require('express');
const axios = require('axios');
const fs = require('fs');
const app = express();
app.use(express.json());

const ORDERS_FILE = './orders.json';

const readOrders = () => {
  try {
    const data = fs.readFileSync(ORDERS_FILE, 'utf-8');
    return data ? JSON.parse(data) : [];
  } catch (err) {
    console.error('Error reading orders.json:', err.message);
    return [];
  }
};

const writeOrders = (orders) => {
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2));
};

app.get('/orders', (req, res) => {
  const orders = readOrders();
  res.json(orders);
});

app.get('/orders/:id', (req, res) => {
  const orders = readOrders();
  const order = orders.find(o => o.id == req.params.id);
  if (!order) return res.status(404).send('Order not found');
  res.json(order);
});

app.post('/orders', async (req, res) => {
  const { userId, productIds } = req.body;

  try {
    const response = await axios.post('http://localhost:3001/products/validate', { productIds });
    if (!response.data.valid) return res.status(400).send('Invalid product IDs');
  } catch (err) {
    return res.status(500).send('Product validation failed');
  }

  const orders = readOrders();
  const newOrder = {
    id: orders.length ? orders[orders.length - 1].id + 1 : 1,
    userId,
    productIds
  };
  orders.push(newOrder);
  writeOrders(orders);
  res.status(201).json(newOrder);
});

app.put('/orders/:id', (req, res) => {
  let orders = readOrders();
  const idx = orders.findIndex(o => o.id == req.params.id);
  if (idx === -1) return res.status(404).send('Order not found');
  orders[idx] = { ...orders[idx], ...req.body };
  writeOrders(orders);
  res.json(orders[idx]);
});

app.delete('/orders/:id', (req, res) => {
  let orders = readOrders();
  orders = orders.filter(o => o.id != req.params.id);
  writeOrders(orders);
  res.sendStatus(204);
});


app.get('/orders/user/:userId', async (req, res) => {
  const orders = readOrders().filter(o => o.userId == req.params.userId);

  const enhancedOrders = await Promise.all(orders.map(async (order) => {
    let user = {};
    try {
      const userRes = await axios.get(`http://localhost:3000/users/${order.userId}`);
      user = userRes.data;
    } catch {
      user = { id: order.userId, name: 'Unknown', email: 'N/A' };
    }

    let products = [];
    for (const productId of order.productIds) {
      try {
        const productRes = await axios.get(`http://localhost:3001/products/${productId}`);
        products.push(productRes.data);
      } catch {
        products.push({ id: productId, name: 'Unknown', price: 0 });
      }
    }

    return {
      id: order.id,
      user,
      products
    };
  }));

  res.json(enhancedOrders);
});


app.listen(3002, () => console.log('Order Service port 3002'));

const express = require('express');
const axios = require('axios');
const fs = require('fs');
const app = express();
app.use(express.json());

const USERS_FILE = './users.json';


const readUsers = () => {
  const data = fs.readFileSync(USERS_FILE);
  return JSON.parse(data);
};

const writeUsers = (users) => {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
};


app.get('/users', (req, res) => {
  const users = readUsers();
  res.json(users);
});

app.post('/users', (req, res) => {
  const users = readUsers();
  const newUser = {
    id: users.length ? users[users.length - 1].id + 1 : 1,
    ...req.body
  };
  users.push(newUser);
  writeUsers(users);
  res.status(201).json(newUser);
});

app.get('/users/:id', (req, res) => {
  const users = readUsers(); 
  const user = users.find(u => u.id == req.params.id); 
  if (!user) return res.status(404).send('User not found');
  res.json(user); 
});


app.put('/users/:id', (req, res) => {
  let users = readUsers();
  const idx = users.findIndex(u => u.id == req.params.id);
  if (idx === -1) return res.status(404).send('User not found');
  users[idx] = { ...users[idx], ...req.body };
  writeUsers(users);
  res.json(users[idx]);
});

app.delete('/users/:id', (req, res) => {
  let users = readUsers();
  users = users.filter(u => u.id != req.params.id);
  writeUsers(users);
  res.sendStatus(204);
});

app.get('/users/:id/orders', async (req, res) => {
  try {
    const response = await axios.get(`http://localhost:3002/orders/user/${req.params.id}`);
    res.json(response.data);
  } catch (err) {
    res.status(500).send('Error fetching orders');
  }
});

app.listen(3000, () => console.log('User Service on port 3000'));

const express = require('express');
const fs = require('fs');
const app = express();
app.use(express.json());

const PRODUCTS_FILE = './products.json';

const readProducts = () => {
  try {
    const data = fs.readFileSync(PRODUCTS_FILE, 'utf-8');
    return data ? JSON.parse(data) : [];
  } catch (err) {
    console.error('Error reading products.json:', err.message);
    return [];
  }
};

const writeProducts = (products) => {
  fs.writeFileSync(PRODUCTS_FILE, JSON.stringify(products, null, 2));
};

app.get('/',(req,res)=>{
  res.send("hello from products")
})
app.get('/products', (req, res) => {
  const products = readProducts();
  res.json(products);
});

app.get('/products/:id', (req, res) => {
  const products = readProducts();
  const product = products.find(p => p.id == req.params.id);
  if (!product) return res.status(404).send('Product not found');
  res.json(product);
});

app.post('/products', (req, res) => {
  const products = readProducts();
  const newProduct = {
    id: products.length ? products[products.length - 1].id + 1 : 1,
    ...req.body
  };
  products.push(newProduct);
  writeProducts(products);
  res.status(201).json(newProduct);
});

app.put('/products/:id', (req, res) => {
  let products = readProducts();
  const idx = products.findIndex(p => p.id == req.params.id);
  if (idx === -1) return res.status(404).send('Product not found');
  products[idx] = { ...products[idx], ...req.body };
  writeProducts(products);
  res.json(products[idx]);
});

app.delete('/products/:id', (req, res) => {
  let products = readProducts();
  products = products.filter(p => p.id != req.params.id);
  writeProducts(products);
  res.sendStatus(204);
});


app.post('/products/validate', (req, res) => {
  const products = readProducts();
  const { productIds } = req.body;
  const valid = productIds.every(id => products.some(p => p.id === id));
  res.json({ valid });
});

app.listen(3001, () => console.log('Product Service port 3001'));
